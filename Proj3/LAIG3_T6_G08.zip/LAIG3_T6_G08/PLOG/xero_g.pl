:- consult('src/display.pl').
:- consult('src/utils.pl').
:- consult('src/board_ops.pl').
:- consult('src/game_ai.pl').
:- consult('src/menu.pl').
:- consult('src/game.pl').
:- use_module(library(lists)).
:- use_module(library(random)).
:- use_module(library(between)).

/*
* Main.
*/
play:-
    menu.
    

    


