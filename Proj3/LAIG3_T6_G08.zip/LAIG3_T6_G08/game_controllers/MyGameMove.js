class MyGameMove {
  constructor(board, orig, dest, piece) {
    this.orig = orig;
    this.dest = dest;
    this.piece = piece;
    this.board = board;
  }
}
